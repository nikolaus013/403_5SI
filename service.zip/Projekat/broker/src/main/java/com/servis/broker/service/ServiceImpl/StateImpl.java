package com.servis.broker.service.ServiceImpl;

import com.fasterxml.jackson.databind.util.JSONPObject;
import com.servis.broker.model.Context;
import com.servis.broker.model.Service1;
import com.servis.broker.model.ServiceRequest;
import com.servis.broker.service.State;
import netscape.javascript.JSException;
import netscape.javascript.JSObject;
import org.springframework.boot.jackson.JsonObjectDeserializer;
import org.springframework.web.client.RestTemplate;

public class StateImpl implements State {

    private final CRUDService crudService;

    public StateImpl(CRUDService crudService) {

        this.crudService = crudService;
    }


    @Override
    public Context callService(Context context) {

        String servis =  context.getService1().getNazivServisa();
        if(servis.equals("Teski klijent")){

            //pozvati teskog klijenta
            //na osnovu uri u teskom klijentu videti sta treba da uradi
            RestTemplate restTemplate = new RestTemplate();
            String Uri  = context.getService1().getHostServisa() + '/' + context.getEndpoint().getNaziv() + '/' + context.getParametar();
            Context context1 = restTemplate.postForObject(Uri, context, Context.class);

            //pozvati novu app i proslediti joj novi json
            //uri za novu app
            Uri  = "hostNoveApp/" + context.getEndpoint().getNaziv() + '/' + context.getParametar();
            return restTemplate.postForObject(Uri, context1, Context.class);


        }
        else{

            //pozvati teskog klijenta proslediti joj sta nam treba iz baze, ona nam vrati json
            RestTemplate restTemplate = new RestTemplate();
            String Uri  = context.getService1().getHostServisa() + '/' + context.getEndpoint().getNaziv() + '/' + context.getParametar();
            Context context1 = restTemplate.postForObject(Uri, context, Context.class);
            JSONPObject test = JS
            //pozvati app prosledjujemo joj json ona nam dodaje u mongo/arango ako vec ne postoji tamo
            Uri  = "hostNoveApp/" + context.getEndpoint().getNaziv() + '/' + context.getParametar();
            Context context2 = restTemplate.postForObject(Uri, context1, Context.class);
            //pozvati servis
            Uri  = context.getService1().getHostServisa() + '/' + context.getEndpoint().getNaziv() + '/' + context.getParametar();
            return restTemplate.postForObject(Uri, context2, Context.class);


        }



    }
}
