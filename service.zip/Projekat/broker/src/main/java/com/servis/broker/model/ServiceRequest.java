package com.servis.broker.model;

import lombok.Data;

import javax.persistence.*;


@Data
public class ServiceRequest {



    String zahtev;



}
