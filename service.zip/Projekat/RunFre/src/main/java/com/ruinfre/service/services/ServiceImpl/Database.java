package com.ruinfre.service.services.ServiceImpl;

import com.fasterxml.jackson.core.JsonParser;
import com.mongodb.MongoClient;
import com.mongodb.client.MongoDatabase;
import com.mysql.cj.xdevapi.JsonArray;

import com.ruinfre.service.controllers.mongoController;
import com.ruinfre.service.domain.Generate;
import com.ruinfre.service.domain.Pom;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.web.client.RestTemplate;




public class Database {

    MongoClient mongoClient = mongoController.getConnection();
    MongoDatabase database = mongoClient.getDatabase("tim_403_5_mongo_si2019");
    MongoTemplate mongo;

    private void populateDatabase(String name) {
        Query query = new Query();
        query.addCriteria(Criteria.where("name").regex(name));
        Generate generate = mongo.findOne(query, Generate.class);
        Pom pom = new Pom();
        pom.setQuery(generate.getQuery());
        pom.setDatabaseType("MongoDB");
        pom.setFieldCount(generate.getFieldCount());
        pom.setScheme(generate.getScheme());
        pom.setTable(generate.getTable());
        pom.setChangeQuery(generate.getChangeQuery());
        pom.setPrimaryKeyColumn(generate.getPrimaryKeyColumn());
        RestTemplate restTemplate = new RestTemplate();
        String response = restTemplate.postForObject("http://localhost:8084/transform/", pom, String.class);
        //dodati u bazu
    }
}
