package com.ruinfre.service.controllers;

import com.mongodb.MongoClient;
import com.mongodb.client.MongoDatabase;
import com.ruinfre.service.services.ServiceImpl.Student1Impl;
import com.ruinfre.service.services.ServiceImpl.Student2Impl;
import com.ruinfre.service.utils.Constants;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;

public class GenerateController1 {
    Student1Impl student1 = new Student1Impl();
    Student2Impl student2 = new Student2Impl();
    MongoClient mongoClient = mongoController.getConnection();
    MongoDatabase database = mongoClient.getDatabase("tim_403_5_mongo_si2019");
    MongoTemplate mongoTemplate;

    @RequestMapping(path = "/{student}")
            public Double srednjaOcena(@PathVariable("student") String student){

            //pozivam broker da mi vrati iz baze studnte
            RestTemplate restTemplate = new RestTemplate();
            String Uri  =  Constants.BROKER +'/'+ student;
            JSONObject body = restTemplate.getForObject(Uri, JSONObject.class);

    JSONArray jsonList = body.getJSONObject(student).getJSONArray("ocene");
    ArrayList<Integer> ocene = new ArrayList<Integer>();
        if (jsonList != null) {
        int len = jsonList.length();
        for (int i=0;i<len;i++){
            ocene.add(jsonList.optInt(i));
        }
    }
    Double srednjaOcena = student1.calcAvgGrade(ocene);

    //pozivam opet brokera da ubacim u mongo
    Uri = "http://localhost:8084/broker/transform/";
        restTemplate.postForObject(Uri, body, JSONObject.class);

        return srednjaOcena;
}

    @RequestMapping(path = "/sumaUplata/{student}")
    public Integer sumaUplata(@PathVariable("student") String student) {

        RestTemplate restTemplate = new RestTemplate();
        String Uri  =  Constants.BROKER +'/'+ student;
        JSONObject body = restTemplate.getForObject(Uri, JSONObject.class);

        JSONArray jsonList = body.getJSONObject(student).getJSONArray("uplate");
        ArrayList<Integer> uplate = new ArrayList<Integer>();
        if (jsonList != null) {
            int len = jsonList.length();
            for (int i=0;i<len;i++){
                uplate.add(jsonList.optInt(i));
            }
        }
        Integer ukupnoUplate = student2.avgSumaUplata(uplate);
        Uri = Constants.BROKER + "/mongoDB/" + student + "/uplate";
        restTemplate.postForObject(Uri, body, JSONObject.class);

        return ukupnoUplate;
    }

    @RequestMapping(path = "/polozeniIspiti/{student}")
    public ArrayList<String> polozeniIspiti(@PathVariable("student") String student) {


        RestTemplate restTemplate = new RestTemplate();
        String Uri  =  Constants.BROKER +'/'+ student;
        JSONObject body = restTemplate.getForObject(Uri, JSONObject.class);

        JSONObject jsonPredmet= body.getJSONObject(student).getJSONObject("predmet");
        JSONArray jsonListPredmeta = body.getJSONObject(student).getJSONArray("predmet");
        ArrayList<String> polozeniPredmeti = new ArrayList<String>();
        if (jsonListPredmeta != null) {
            int len = jsonListPredmeta.length();
            for (int i=0;i<len;i++){
                JSONObject ocenaJson = jsonPredmet.getJSONObject(jsonListPredmeta.optString(i));
                Integer ocena = ocenaJson.optInt("ocena");
                if(ocena > 5){
                    polozeniPredmeti.add(jsonListPredmeta.optString(i));
                }
            }
        }

        Uri = Constants.BROKER + "/mongoDB/" + student + "/predmeti";
        restTemplate.postForObject(Uri, body, JSONObject.class);
        return polozeniPredmeti;

    }

    @RequestMapping(path = "/{query}/{student}")
    public ArrayList<String> polozeniIspiti(@PathVariable("student") String student,@PathVariable("query") Query query) {


        RestTemplate restTemplate = new RestTemplate();
        String Uri  =  Constants.BROKER +'/'+ student;
        JSONObject body = restTemplate.getForObject(Uri, JSONObject.class);

        JSONObject jsonPredmet= body.getJSONObject(student).getJSONObject("predmet");
        JSONArray jsonListPredmeta = body.getJSONObject(student).getJSONArray("predmet");
        ArrayList<String> polozeniPredmeti = new ArrayList<String>();
        if (jsonListPredmeta != null) {
            int len = jsonListPredmeta.length();
            for (int i=0;i<len;i++){
                JSONObject ocenaJson = jsonPredmet.getJSONObject(jsonListPredmeta.optString(i));
                Integer ocena = ocenaJson.optInt("ocena");
                if(ocena > 5){
                    polozeniPredmeti.add(jsonListPredmeta.optString(i));
                }
            }
        }

        Uri = Constants.BROKER + "/mongoDB/" + student + "/predmeti";
        restTemplate.postForObject(Uri, body, JSONObject.class);
        return polozeniPredmeti;

    }


}


