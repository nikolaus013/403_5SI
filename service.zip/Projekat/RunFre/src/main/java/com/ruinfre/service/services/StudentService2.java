package com.ruinfre.service.services;

import java.util.ArrayList;

public interface StudentService2 {

    Integer avgSumaUplata(ArrayList<Integer> list);
}
