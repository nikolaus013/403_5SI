package com.ruinfre.service.services;

import java.util.ArrayList;

public interface StudentService1 {
    Double calcAvgGrade(ArrayList<Integer> list);
}
