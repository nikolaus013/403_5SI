package com.ruinfre.service.services;

import com.ruinfre.service.api.v1.model.GenerateDTO;
import com.ruinfre.service.domain.Generate;
import org.json.JSONArray;
import org.springframework.http.ResponseEntity;

public interface generateReportInterface {
    ResponseEntity<JSONArray> generateReport(Generate generate);
}
