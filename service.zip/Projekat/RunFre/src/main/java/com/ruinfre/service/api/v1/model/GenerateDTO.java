package com.ruinfre.service.api.v1.model;

public class GenerateDTO {


}
