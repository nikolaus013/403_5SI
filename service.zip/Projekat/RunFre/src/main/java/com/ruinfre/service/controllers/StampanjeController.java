package com.ruinfre.service.controllers;

import com.ruinfre.service.services.ServiceImpl.Student1Impl;
import com.ruinfre.service.services.ServiceImpl.Student2Impl;
import com.ruinfre.service.utils.Constants;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;

@Controller
@RequestMapping(Constants.STAMPANJE)
public class StampanjeController {

}
