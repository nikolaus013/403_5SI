package com.ruinfre.service.services.ServiceImpl;

import com.ruinfre.service.api.v1.model.GenerateDTO;
import com.ruinfre.service.domain.Generate;
import com.ruinfre.service.services.generateReportInterface;
import jdk.nashorn.internal.parser.JSONParser;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.BasicQuery;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import java.text.ParseException;
import java.util.List;

public class generateReport implements generateReportInterface {

    MongoTemplate mt;


    @Override
    public ResponseEntity<JSONArray> generateReport(Generate generate) {
            BasicQuery basicQuery = new BasicQuery(String.valueOf(generate.getFieldCount()));
            basicQuery.addCriteria(Criteria.where("courseName").is(generate.getEquality()));
            for (String field : generate.getIncludedFields()) {
                basicQuery.fields().include(field);
            }
            basicQuery.fields().exclude("_id");
            JSONParser parser = new JSONParser();
            JSONArray array = new JSONArray();
            List<String> res = mt.find(basicQuery, String.class, generate.getName());
            for (String s : res) {
                JSONObject object = null;
                try {
                    object = (JSONObject) parser.parse(s);
                    array.add(object);
                } catch (ParseException e) {
                    e.printStackTrace();
                }
            }
            logger.error(array.toJSONString());
            return new ResponseEntity<>(array, HttpStatus.OK);
        }
    }
}

