package com.ruinfre.service.services.ServiceImpl;

import com.ruinfre.service.services.StudentService2;
import org.springframework.stereotype.Service;

import java.util.ArrayList;

@Service
public class Student2Impl implements StudentService2 {


    @Override
    public Integer avgSumaUplata(ArrayList<Integer> list) {
        int sum = 0;
        ArrayList<Integer> uplata = list;
        for(int i=0;i < uplata.size(); i++){
            sum += uplata.indexOf(i);
        }
        return sum;
    }
}
