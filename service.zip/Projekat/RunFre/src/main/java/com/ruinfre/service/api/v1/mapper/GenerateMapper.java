package com.ruinfre.service.api.v1.mapper;

import com.ruinfre.service.api.v1.model.GenerateDTO;
import com.ruinfre.service.domain.Generate;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface GenerateMapper {

        GenerateMapper instance = Mappers.getMapper(GenerateMapper.class);

        GenerateDTO generaatDTO(Generate generate);

    }

