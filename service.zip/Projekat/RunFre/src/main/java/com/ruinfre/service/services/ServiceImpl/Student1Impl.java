package com.ruinfre.service.services.ServiceImpl;

import com.ruinfre.service.domain.Ocena;
import com.ruinfre.service.services.StudentService1;
import org.springframework.stereotype.Service;

import java.util.ArrayList;

@Service
public class Student1Impl implements StudentService1 {

    @Override
    public Double calcAvgGrade(ArrayList<Integer> list) {
        int sum = 0;
        int br = 0;
        ArrayList<Integer> ocena = list;
        for(int i=0;i < ocena.size(); i++){
            sum += ocena.indexOf(i);
            br++;
        }
        Double  rez= Double.valueOf(sum/br);
        return rez;

    }
}
