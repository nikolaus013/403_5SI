package com.ruinfre.service.controllers;

import com.mongodb.MongoClient;
import com.mongodb.client.MongoDatabase;
import com.ruinfre.service.domain.Generate;
import com.ruinfre.service.services.ServiceImpl.Student1Impl;
import com.ruinfre.service.services.ServiceImpl.Student2Impl;
import com.ruinfre.service.services.ServiceImpl.generateReport;
import com.ruinfre.service.utils.Constants;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;


@Controller
@RequestMapping(Constants.GENERISANJE)
public class GenerisanjeController {

    Student1Impl student1 = new Student1Impl();
    Student2Impl student2 = new Student2Impl();
    com.ruinfre.service.services.ServiceImpl.generateReport generateReport = new generateReport();
    MongoClient mongoClient = mongoController.getConnection();
    MongoDatabase database = mongoClient.getDatabase("tim_403_5_mongo_si2019");
    MongoTemplate mongoTemplate;

    @RequestMapping(path = "/{generate}")
    public void generate(@PathVariable("generate") Generate generate) {


        String name = generate.getName();
        if (mongoTemplate.collectionExists(name)) {
             generateReport.generateReport(generate);
        }
        Query query = new Query();


    }
}
