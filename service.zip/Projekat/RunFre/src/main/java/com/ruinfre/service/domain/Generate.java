package com.ruinfre.service.domain;
import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(value = "generate")
@Data
public class Generate {
    @Id
    public String id;
    public String name;
    public String query;
    public String scheme;
    public Integer fieldCount;
    public String table;
    public String changeQuery;
    public String primaryKeyColumn;
 }