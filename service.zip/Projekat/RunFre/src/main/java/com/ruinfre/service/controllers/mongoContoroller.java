package com.ruinfre.service.controllers;

import com.mongodb.MongoClient;
import com.mongodb.MongoCredential;
import com.mongodb.ServerAddress;

import java.util.Arrays;

class mongoController {

    private static String user = "tim_403_5_mongo_si2019";
    private static String database = "tim_403_5_mongo_si2019";
    private static String password = "5LMTdnk4";

    public static MongoClient getConnection(){
        MongoCredential credential = MongoCredential.createCredential(user, database, password.toCharArray());
        MongoClient mongoClient = new MongoClient(new ServerAddress("64.225.110.65",27017), Arrays.asList(credential));
        System.out.println("Konektovan");
        return mongoClient;
    }
}