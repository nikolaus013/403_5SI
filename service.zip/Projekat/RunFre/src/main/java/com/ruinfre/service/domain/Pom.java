package com.ruinfre.service.domain;
import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.ArrayList;
import java.util.List;
@Document(value = "generate")
@Data
public class Pom {
    @Id
    public String id;
    public String name;
    public String query;
    public String databaseType;
    public Integer fieldCount;
    public String scheme;
    public String table;
    public String changeQuery;
    public String primaryKeyColumn;
}