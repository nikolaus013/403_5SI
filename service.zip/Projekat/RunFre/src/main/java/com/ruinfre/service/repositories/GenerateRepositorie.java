package com.ruinfre.service.repositories;

public interface GenerateRepositorie {
}
